# IGOR R17.31 — pesquisa (2026-11-28T01:33:10.592000+00:00)

Cérebro: `deterministic_baseline`. Estado: pesquisa; ordens reais: 0.

**Não houve execução, preenchimento ou medição de rentabilidade neste ciclo.**

| Ativo | Contexto 4h | Hipótese | 24h | Spread bps | Funding observado | Decisão |
|---|---|---|---:|---:|---:|---|
| ETHUSDT | trending | short | -2.34% | 0.060 | 0.00628% | HOLD |
| BTCUSDT | trending | short | -1.31% | 0.017 | 0.00808% | HOLD |
| BNBUSDT | trending | short | -0.16% | 0.180 | 0.00600% | HOLD |
| SOLUSDT | mean_reverting | neutral | 0.66% | 1.388 | 0.00821% | HOLD |
| DOGEUSDT | mean_reverting | neutral | 2.09% | 1.726 | -0.00130% | HOLD |
| XRPUSDT | mean_reverting | neutral | 0.31% | 1.050 | 0.00410% | HOLD |

O ranking é força técnica descritiva; não é expectativa de lucro nem probabilidade calibrada.

## ETHUSDT

Contexto 4h trending; variação 24h -2.34%. Hipótese técnica exploratória.

Risco da tese: Custos, reversão e ausência de catalisador fundamental podem eliminar a vantagem.

Invalidação: Invalidar com dados obsoletos, reversão do contexto 4h ou falha da validação líquida fora da amostra.

Pendências: supply_and_unlocks, revenue_and_fees, tvl_and_users, holder_concentration, token_value_accrual, verified_token_catalysts.

Bloqueios: UNVALIDATED_STRATEGY, NO_EXECUTION_ADAPTER, UNCALIBRATED_PROBABILITY, INCOMPLETE_FUNDAMENTAL_EVIDENCE.

Fontes de dados: ETHUSDT:hourly, ETHUSDT:four_hourly, ETHUSDT:book, ETHUSDT:funding, ETHUSDT:open_interest, CONTEXT:supply, CONTEXT:chains.

## BTCUSDT

Contexto 4h trending; variação 24h -1.31%. Hipótese técnica exploratória.

Risco da tese: Custos, reversão e ausência de catalisador fundamental podem eliminar a vantagem.

Invalidação: Invalidar com dados obsoletos, reversão do contexto 4h ou falha da validação líquida fora da amostra.

Pendências: supply_and_unlocks, revenue_and_fees, tvl_and_users, holder_concentration, token_value_accrual, verified_token_catalysts.

Bloqueios: UNVALIDATED_STRATEGY, NO_EXECUTION_ADAPTER, UNCALIBRATED_PROBABILITY, INCOMPLETE_FUNDAMENTAL_EVIDENCE.

Fontes de dados: BTCUSDT:hourly, BTCUSDT:four_hourly, BTCUSDT:book, BTCUSDT:funding, BTCUSDT:open_interest, CONTEXT:supply, CONTEXT:chains.

## BNBUSDT

Contexto 4h trending; variação 24h -0.16%. Hipótese técnica exploratória.

Risco da tese: Custos, reversão e ausência de catalisador fundamental podem eliminar a vantagem.

Invalidação: Invalidar com dados obsoletos, reversão do contexto 4h ou falha da validação líquida fora da amostra.

Pendências: supply_and_unlocks, revenue_and_fees, tvl_and_users, holder_concentration, token_value_accrual, verified_token_catalysts.

Bloqueios: UNVALIDATED_STRATEGY, NO_EXECUTION_ADAPTER, UNCALIBRATED_PROBABILITY, INCOMPLETE_FUNDAMENTAL_EVIDENCE.

Fontes de dados: BNBUSDT:hourly, BNBUSDT:four_hourly, BNBUSDT:book, BNBUSDT:funding, BNBUSDT:open_interest, CONTEXT:supply, CONTEXT:chains.

## SOLUSDT

Contexto 4h mean_reverting; variação 24h 0.66%. Hipótese técnica exploratória.

Risco da tese: Custos, reversão e ausência de catalisador fundamental podem eliminar a vantagem.

Invalidação: Invalidar com dados obsoletos, reversão do contexto 4h ou falha da validação líquida fora da amostra.

Pendências: supply_and_unlocks, revenue_and_fees, tvl_and_users, holder_concentration, token_value_accrual, verified_token_catalysts.

Bloqueios: UNVALIDATED_STRATEGY, NO_EXECUTION_ADAPTER, UNCALIBRATED_PROBABILITY, NEUTRAL_DIRECTION, INCOMPLETE_FUNDAMENTAL_EVIDENCE.

Fontes de dados: SOLUSDT:hourly, SOLUSDT:four_hourly, SOLUSDT:book, SOLUSDT:funding, SOLUSDT:open_interest, CONTEXT:supply, CONTEXT:chains.

## DOGEUSDT

Contexto 4h mean_reverting; variação 24h 2.09%. Hipótese técnica exploratória.

Risco da tese: Custos, reversão e ausência de catalisador fundamental podem eliminar a vantagem.

Invalidação: Invalidar com dados obsoletos, reversão do contexto 4h ou falha da validação líquida fora da amostra.

Pendências: supply_and_unlocks, revenue_and_fees, tvl_and_users, holder_concentration, token_value_accrual, verified_token_catalysts.

Bloqueios: UNVALIDATED_STRATEGY, NO_EXECUTION_ADAPTER, UNCALIBRATED_PROBABILITY, NEUTRAL_DIRECTION, INCOMPLETE_FUNDAMENTAL_EVIDENCE.

Fontes de dados: DOGEUSDT:hourly, DOGEUSDT:four_hourly, DOGEUSDT:book, DOGEUSDT:funding, DOGEUSDT:open_interest, CONTEXT:supply.

## XRPUSDT

Contexto 4h mean_reverting; variação 24h 0.31%. Hipótese técnica exploratória.

Risco da tese: Custos, reversão e ausência de catalisador fundamental podem eliminar a vantagem.

Invalidação: Invalidar com dados obsoletos, reversão do contexto 4h ou falha da validação líquida fora da amostra.

Pendências: supply_and_unlocks, revenue_and_fees, tvl_and_users, holder_concentration, token_value_accrual, verified_token_catalysts.

Bloqueios: UNVALIDATED_STRATEGY, NO_EXECUTION_ADAPTER, UNCALIBRATED_PROBABILITY, NEUTRAL_DIRECTION, INCOMPLETE_FUNDAMENTAL_EVIDENCE.

Fontes de dados: XRPUSDT:hourly, XRPUSDT:four_hourly, XRPUSDT:book, XRPUSDT:funding, XRPUSDT:open_interest, CONTEXT:supply, CONTEXT:chains.

## Cobertura e limitações

Snapshot REST não fornece fila maker. Funding observado não garante o próximo pagamento.

Dominância BTC: 57.81254368840105.

Stablecoins (proxy de oferta, não liquidez executável): {"usd_pegged_supply_usd": 282160032141.18, "change_7d_fraction": -0.0012126892974140269, "source_id": "CONTEXT:stablecoins", "provider_timestamp_ms": 1795824000000, "scope": "USD-pegged supply proxy; not executable order-book liquidity"}. Rotação narrativa: não apurada.

Símbolos rejeitados: 0. Erros de coleta: 0.

## Notícias de fontes primárias

- [Devcon 8 India Recap: Four Days in Mumbai, and What's Next](https://blog.ethereum.org/en/2026/11/25/devcon-mumbai-wrap)
- [PQAI #1: One hash to rule them all — Keccak-256 for Ethereum's post-quantum, post-AI era](https://blog.ethereum.org/en/2026/11/24/pqai-1)
- [PQAI #0: Preparing Ethereum for a post-quantum, post-AI world](https://blog.ethereum.org/en/2026/11/23/pqai-0)
- [Agencies announce dollar thresholds for applicability of truth in lending and consumer leasing rules for consumer credit and lease transactions](https://www.federalreserve.gov/newsevents/pressreleases/bcreg20261125b.htm)
- [Agencies announce dollar thresholds for smaller loan exemption from appraisal requirements for higher-priced mortgage loans](https://www.federalreserve.gov/newsevents/pressreleases/bcreg20261125a.htm)
- [Minutes of the Board's discount rate meetings on October 19 and October 28, 2026](https://www.federalreserve.gov/newsevents/pressreleases/monetary20261124a.htm)

Manchetes não foram classificadas como catalisadores confirmados dos tokens.

## Revisão

{
  "label_count": 0,
  "rejected_labels": 0,
  "errors": [],
  "brier_score": null,
  "calibration_status": "NOT_MEASURED_NO_MATURED_LABELS",
  "automatic_code_changes": 0,
  "automatic_promotions": 0,
  "next_action": "Collect independent matured labels and compare costs before any promotion."
}

## O QUE PODEMOS ESTAR ERRANDO?

O contexto técnico pode não ter vantagem líquida; há lacunas fundamentais, custos variáveis, seleção adversa e risco de sobreajuste. A opinião da IA não é uma probabilidade calibrada. Esquema/citações válidos não comprovam a verdade das interpretações do modelo.

## Proveniência

Snapshot SHA256: `8eff401019dd88b46dcb1bc645b10d560ad9dcae0b7884bf5722eae8abde9b51`. Pesquisa SHA256: `aeb66e7ead5cd1a5516a61ee5c6a0c5d348b2b5c8ca03fcdb1dbe9ad81f7e2e3`.

As respostas públicas integrais e horários de recebimento estão em snapshot.json.
